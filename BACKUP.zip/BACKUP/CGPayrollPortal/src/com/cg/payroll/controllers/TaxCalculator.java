package com.cg.payroll.controllers;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
@WebServlet("/TaxCalculator")
public class TaxCalculator extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private PayrollServices services;
	@Override
	public void init() throws ServletException {
	services=new PayrollServicesImpl();
	}
  	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  		RequestDispatcher dispatcher=null;
  		int associateId = Integer.parseInt(request.getParameter("associateId"));
  		Associate associate=services.getAssociateDetails(associateId);
  		double netSalary=services.taxCalculator(associateId);
  		try {
  			associate.getSalary().setNetSalary((int)netSalary);
   			request.setAttribute("associate",associate);
   			request.getRequestDispatcher("netSuccess.jsp").forward(request, response);
   		}catch(AssociateDetailsNotFoundException e) {
   			e.printStackTrace();
   		}}
   	@Override
		public void destroy() {
			services=null;
		}
}
