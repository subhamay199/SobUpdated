function sayHello() {
	document.getElementById("msg").innerHTML="<font color='red' size=5>Hello World On Browser</font>"
	console.log("Hello World On Console")
} 
function sayHello2(){
	alert("Hello")
}