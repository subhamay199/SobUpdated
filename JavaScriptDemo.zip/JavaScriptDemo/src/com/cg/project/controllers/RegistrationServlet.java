package com.cg.project.controllers;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.Associate;
@WebServlet("/registration")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   		
   		int associateId=Integer.parseInt(request.getParameter("associateId")); 
   		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String password=request.getParameter("password");
		String emailId=request.getParameter("emailId");	
		String mobileNo=request.getParameter("mobileNo");	
		String gender=request.getParameter("gender");	
		String graduation=request.getParameter("graduation");
		List<String> communication=Arrays.asList(request.getParameterValues("communication"));
		Associate associate=new Associate(associateId, password, firstName, lastName, emailId, gender, mobileNo, communication);
		RequestDispatcher dispatcher=request.getRequestDispatcher("welcomePage.jsp");
   	}

}
