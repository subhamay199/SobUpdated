package com.cg.project.beans;

import java.util.List;

public class Associate {
private int associateId;
private String password,firstName,lastName,emailId,gender,mobileNo;
private List<String> communication;
public Associate() {}
public Associate(int associateId, String password) {
	super();
	this.associateId = associateId;
	this.password = password;
}

public Associate(int associateId, String password, String firstName, String lastName, String emailId, String gender,
		String mobileNo, List<String> communication) {
	super();
	this.associateId = associateId;
	this.password = password;
	this.firstName = firstName;
	this.lastName = lastName;
	this.emailId = emailId;
	this.gender = gender;
	this.mobileNo = mobileNo;
	this.communication = communication;
}
public int getAssociateId() {
	return associateId;
}
public void setAssociateId(int associateId) {
	this.associateId = associateId;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public List<String> getCommunication() {
	return communication;
}
public void setCommunication(List<String> communication) {
	this.communication = communication;
}
@Override
public String toString() {
	return "Associate [associateId=" + associateId + ", password=" + password + ", firstName=" + firstName
			+ ", lastName=" + lastName + ", emailId=" + emailId + ", gender=" + gender + ", communication="
			+ communication + "]";
}


}
