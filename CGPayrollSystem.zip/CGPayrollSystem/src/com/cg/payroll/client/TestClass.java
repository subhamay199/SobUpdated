package com.cg.payroll.client;

import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class TestClass {
	public static void main(String args[]) {
		PayrollServices services=new PayrollServicesImpl();
		int associateId=services.acceptAssociateDetails("Subhamaya", "Samanta", "subhamaysamnata1997@gmail.com", "IT", "Analyst", "dfggd", 204300, 32540, 1500, 1600, 3793, "sbi", "dgfdf5363");
		System.out.println("Associate Id:- "+associateId);
		int associateId2=services.acceptAssociateDetails("koyel", "ganguly", "koyel98@gmail.com", "IT", "Analyst", "fdghd", 25000, 14000, 1700, 1500, 4321, "axis", "axis821437");
		System.out.println("Associate Id:- "+associateId2);
//		PayrollDBUtil.getDBConnection();
//		System.out.println("Connection is open");
	}
}
